<?php $__env->startSection('page-title', $restaurant->res_name . ' Add New Campaign'); ?>

<?php $__env->startSection('custom-css'); ?>

<link href="<?php echo e(asset('css/toggles.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/bootstrap-timepicker.min.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-contents'); ?>

<section>
    <div class="mainwrapper">

        <?php echo $__env->make('layouts.sidebar-admin', ['restaurant' => $restaurant], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="mainpanel">
            <div class="pageheader">
                <div class="media">
                    <div class="pageicon pull-left">
                        <i class="fa fa-plus-square"></i>
                    </div>
                    <div class="media-body">
                        <ul class="breadcrumb">
                            <li><a href="<?php echo e(url('dashboard')); ?>"><i class="glyphicon glyphicon-home"></i></a></li>
                            <li>Add New Campaign</li>
                        </ul>
                        <h4>Add New Campaign</h4>
                    </div>
                </div><!-- media -->
            </div><!-- pageheader -->

            <div class="contentpanel">
                <div class="col-sm-12 col-md-8 col-xs-12" style="padding-bottom:20px;">
                	<?php if(session('message')): ?>

                    <div class="alert alert-success">
                        <strong><?php echo e(session('message')); ?></strong>
                    </div>

	                <?php endif; ?>

	                <?php if(count($errors) > 0): ?>

                    <div class="alert alert-danger">
                        <ul class="media-list">

                        <?php foreach($errors as  $v): ?>

                            <li class="media">

                                  <strong> <?php echo e(str_replace('.1', '', $v[0])); ?></strong>

                            </li>

                        <?php endforeach; ?>

                        </ul>
                    </div>

	                <?php endif; ?>
					<form class="form-horizontal form-bordered" style="display:inline;" action="<?php echo e(url('campaigns')); ?>" method="POST">

                        <div class="form-group">
                            <label class="col-sm-2 control-label" style="text-align:left;">Merchant Name *</label>
                            <div class="col-sm-8">
                                <input type="hidden" value="<?php echo e(csrf_token()); ?>" name="_token">
                                <select id="select_merchants" name="merchant_id" data-placeholder="Choose One" style="width:100%;" tabindex="-1" title="" class="select2-offscreen">
                                    <option value="">Choose One</option>
                                    <?php foreach($merchants as $merchant): ?>
                                    <option value="<?php echo e($merchant['id']); ?>"><?php echo e($merchant['coy_name']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
						<div class="form-group">
							<label class="col-sm-2 control-label" style="text-align:left;">Campaign Name *</label>
							<div class="col-sm-8">
								<!-- <input type="text" value="" class="form-control" required /> -->
								<?php echo Form::text('campaign_name', null, ['required' => 'required', 'class' => 'form-control']); ?>

							</div>
						</div><!-- form-group -->

						<div class="form-group">
							<label class="col-sm-2 control-label" style="text-align:left;">Timezone *</label>
							<div class="col-sm-8">
								<!-- <input type="text" value="GMT +08:00 (Singapore)" id="disabledinput" class="form-control" disabled="" /> -->
								<?php echo Form::text('cam_timezone', 'GMT +08:00 (Singapore)', ['readonly' => 'readonly', 'required' => 'required', 'class' => 'form-control']); ?>

							</div>
						</div><!-- form-group -->

						<div class="form-group">
							<label class="col-sm-2 control-label" style="text-align:left;">Start Date *</label>
							<div class="col-sm-8">
								<div class="input-group">
                                    <!-- <input type="text" class="form-control" placeholder="DD-MMM-YYYY" id="datepicker" required> -->
                                    <?php echo Form::text('cam_start', null, ['required' => 'required', 'id' => 'datepicker', 'placeholder' => 'YYYY-MM-DD', 'class' => 'form-control']); ?>

                                    <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                                </div><!-- input-group -->
							</div>
						</div><!-- form-group -->

						<div class="form-group">
							<label class="col-sm-2 control-label" style="text-align:left;">End Date *</label>
							<div class="col-sm-8">
								<div class="input-group">
                                    <!-- <input type="text" class="form-control" placeholder="DD-MMM-YYYY" id="datepicker2" required> -->
                                    <?php echo Form::text('cam_end', null, ['required' => 'required' ,'id' => 'datepicker2', 'placeholder' => 'YYYY-MM-DD', 'class' => 'form-control']); ?>

                                    <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                                </div><!-- input-group -->
							</div>
						</div><!-- form-group -->

						<br>

						<button style="margin-left:15px;" class="btn btn-primary">Create and Add New Blurbs</button>

					</form>

					<a href="<?php echo e(url('campaigns')); ?>"><button style="margin-left:15px;" class="btn btn-default">Cancel</button></a>
				</div>
            </div><!-- contentpanel -->

        </div>
    </div><!-- mainwrapper -->
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-js'); ?>

<script type="text/javascript" src="<?php echo e(asset('js/jquery-ui-1.10.3.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/toggles.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/bootstrap-timepicker.min.js')); ?>"></script>

<script type="text/javascript">

	// Date Picker
	jQuery('#datepicker').datepicker({
        dateFormat: 'yy-mm-dd',
        minDate: 0, // 0 days offset = today
        onSelect: function(dateText) {
            $sD = new Date(dateText);
            $("input#datepicker2").datepicker('option', 'minDate', dateText);
        }
    });
	jQuery('#datepicker2').datepicker({
         dateFormat: 'yy-mm-dd',
         minDate: jQuery('#datepicker').val(),
         onSelect: function(dateText) {
            $sD = new Date(dateText);
            $("input#datepicker").datepicker('option', 'maxDate', dateText);
        }

    });
    jQuery('#select_merchants').select2({
        minimumResultsForSearch: -1
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>