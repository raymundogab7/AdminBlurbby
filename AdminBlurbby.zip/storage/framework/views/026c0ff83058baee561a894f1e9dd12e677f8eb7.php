<?php $__env->startSection('page-title', $restaurant->res_name . ' Campaigns'); ?>

<?php $__env->startSection('custom-css'); ?>

<link href="<?php echo e(asset('css/toggles.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/bootstrap-timepicker.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/style.datatables.css')); ?>" rel="stylesheet">
<link href="//cdn.datatables.net/responsive/2.1.0/css/responsive.dataTables.min.css" rel="stylesheet">
<link href="<?php echo e(asset('css/morris.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-contents'); ?>

<section>
	<div class="mainwrapper">

		<?php echo $__env->make('layouts.sidebar-admin', ['restaurant' => $restaurant], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	    <div class="mainpanel">
            <div class="pageheader">
                <div class="media">
                    <div class="pageicon pull-left">
                        <i class="fa fa-tag"></i>
                    </div>
                    <div class="media-body">
                        <ul class="breadcrumb">
                            <li><a href="<?php echo e(url('dashboard')); ?>"><i class="glyphicon glyphicon-home"></i></a></li>
                            <li><a href="<?php echo e(url('campaigns')); ?>">Campaigns</a></li>
                            <li>Campaign Details</li>
                        </ul>
                        <h4>Campaign Details</h4>
                    </div>
                </div><!-- media -->
            </div><!-- pageheader -->
            
            <div class="contentpanel">
                <div class="panel panel-primary-head">
               	 	<?php if(session('message')): ?>

                    <div class="alert alert-success">
                        <strong><?php echo e(session('message')); ?></strong>
                    </div>

	                <?php endif; ?>

	                <?php if(session('message_error')): ?>

                    <div class="alert alert-danger">
                        <strong><?php echo e(session('message_error')); ?></strong>
                    </div>

	                <?php endif; ?>

	                <?php if(count($errors) > 0): ?>

                    <div class="alert alert-danger">
                        <ul class="media-list">

                        <?php foreach($errors as  $v): ?>

                            <li class="media">

                                  <strong> <?php echo e(str_replace('.1', '', $v[0])); ?></strong>

                            </li>

                        <?php endforeach; ?>

                        </ul>
                    </div>

	                <?php endif; ?>
					<?php if($campaign->cam_status == 'Rejected'): ?>

					<?php echo $__env->make('campaign._rejected', ['campaign' => $campaign], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

					<?php elseif($campaign->cam_status == 'Draft'): ?>

					<?php echo $__env->make('campaign._draft', ['campaign' => $campaign], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

					<?php elseif($campaign->cam_status == 'Approved'): ?>

					<?php echo $__env->make('campaign._approved', ['campaign' => $campaign], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

					<?php elseif($campaign->cam_status == 'Live'): ?>

					<?php echo $__env->make('campaign._live', ['campaign' => $campaign], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

					<?php elseif($campaign->cam_status == 'Expired'): ?>

					<?php echo $__env->make('campaign._expired', ['campaign' => $campaign], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

					<?php else: ?>

					<?php echo $__env->make('campaign._pending_approval', ['campaign' => $campaign], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

					<?php endif; ?>

                    
                </div><!-- panel -->
            </div><!-- contentpanel -->
        </div><!-- mainpanel -->
    </div><!-- mainwrapper -->
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-js'); ?>






<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>