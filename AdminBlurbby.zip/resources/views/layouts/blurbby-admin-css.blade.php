<link href="" rel="stylesheet">
<link href="{{asset('css/style.default.css')}}" rel="stylesheet">
<link href="{{asset('css/select2.css')}}" rel="stylesheet">
<link href='https://fonts.googleapis.com/css?family=Arimo' rel='stylesheet' type='text/css'>
<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->
<style type="text/css">
.background-blur {
    -webkit-filter: blur(3px); /* Chrome, Safari, Opera */
    filter: blur(3px);
}
.square {
    background: #00B0ED;
    max-width: 50px;
    min-width: 50px;
    height: 50px;
}
.square p {
    color:#fff;
    text-align:center;
    font-size: 35px
}

.background-blur-profile {
    -webkit-filter: blur(3px); /* Chrome, Safari, Opera */
    filter: blur(3px);
}
.square-profile {
    background: #00B0ED;
    max-width: 80px;
    min-width: 80px;
    height: 75px;
}
.square-profile p {
    color:#fff;
    text-align:center;
    font-size: 35px
}
</style>