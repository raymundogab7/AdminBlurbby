
<script type="text/javascript" src="{{asset('js/jquery-1.11.1.min.js')}}"></script>
<script type="text/javascript" src="{{asset('js/jquery-migrate-1.2.1.min.js')}}"></script>
<script type="text/javascript" src="{{asset('js/bootstrap.min.js')}}"></script>
<script type="text/javascript" src="{{asset('js/modernizr.min.js')}}"></script>
<script type="text/javascript" src="{{asset('js/pace.min.js')}}"></script>
<script type="text/javascript" src="{{asset('js/retina.min.js')}}"></script>
<script type="text/javascript" src="{{asset('js/jquery.cookies.js')}}"></script>
<script type="text/javascript" src="{{asset('js/select2.min.js')}}"></script>
<script type="text/javascript" src="{{asset('js/custom.js')}}"></script>
<script type="text/javascript" src="{{asset('js/merchant.js')}}"></script>
