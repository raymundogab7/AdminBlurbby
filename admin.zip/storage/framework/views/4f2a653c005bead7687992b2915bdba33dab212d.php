<?php $__env->startSection('page-title', 'Merchants'); ?>

<?php $__env->startSection('custom-css'); ?>

<link href="<?php echo e(asset('css/morris.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/style.datatables.css')); ?>" rel="stylesheet">
<link href="//cdn.datatables.net/responsive/2.1.0/css/responsive.dataTables.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-contents'); ?>
	<section>
        <div class="mainwrapper">
        <?php echo $__env->make('layouts.sidebar-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	        <div class="mainpanel">
	            <div class="pageheader">
	                <div class="media">
	                    <div class="pageicon pull-left">
	                        <i class="fa fa-tags"></i>
	                    </div>
	                    <div class="media-body">
	                        <ul class="breadcrumb">
	                            <li><a href="<?php echo e(url('dashboard')); ?>"><i class="glyphicon glyphicon-home"></i></a></li>
	                            <li>Merchants</li>
	                        </ul>
	                        <h4>Merchants</h4>
	                    </div>
	                </div><!-- media -->
	            </div><!-- pageheader -->

	            <div class="contentpanel">

	                <div class="row">
	                    <div class="col-sm-3">

	                        <h5 class="md-title">Merchants</h5>
	                        <ul class="nav nav-pills nav-stacked nav-contacts">
	                            <li class="active">
	                                <a href="#">
	                                    <table><tr><td style="width:100%;">All Merchants</td>
	                                    <td><span class="badge pull-right"><?php echo e($total_merchants); ?></span></td></tr></table>
	                                </a>
	                            </li>
	                            <li>
	                                <a href="#">
	                                    <table><tr><td style="width:100%;">Created in the last 30 days</td>
	                                    <td><span class="badge pull-right"><?php echo e($total_last_thirty_days); ?></span></td></tr></table>
	                                </a>
	                            </li>
	                            <li>
	                                <a href="#">
	                                    <table><tr><td style="width:100%;">Approved</td>
	                                    <td><span class="badge pull-right"><?php echo e($total_approved_merchants); ?></span></td></tr></table>
	                                </a>
	                            </li>
	                            <li>
	                                <a href="#">
	                                    <table><tr><td style="width:100%;">Blocked</td>
	                                    <td><span class="badge pull-right"><?php echo e($total_blocked_merchants); ?></span></td></tr></table>
	                                </a>
	                            </li>
	                            <li>
	                                <a href="#">
	                                    <table><tr><td style="width:100%;">Pending Admin Approval</td>
	                                    <td><span class="badge pull-right"><?php echo e($total_pending_admin_approval_merchants); ?></span></td></tr></table>
	                                </a>
	                            </li>
	                            <li>
	                                <a href="#">
	                                    <table><tr><td style="width:100%;">Pending Email Verification</td>
	                                    <td><span class="badge pull-right"><?php echo e($total_pending_email_verification); ?></span></td></tr></table>
	                                </a>
	                            </li>
	                        </ul>

	                        <hr />

	                    </div><!-- col-sm-3 -->
	                    <div class="col-sm-9">

	                        <div class="well mt10">
	                            <div class="row">
	                                <div class="col-sm-9">
	                                    <input type="text" id="input" value="<?php echo e($search_word); ?>" placeholder="Who are you looking for?" class="form-control">
	                                </div>
	                                <div class="col-sm-3">
	                                    <select id="search-type" class="width100p" data-placeholder="Search Type">
	                                        <option value="">Choose One</option>
	                                        <option value="Company" <?php if($search_type == 'Company') : ?> selected <?php endif; ?>>Company Name</option>
	                                        <option value="Restaurant" <?php if($search_type == 'Restaurant') : ?> selected <?php endif; ?>>Restaurant Name</option>
	                                        <option value="Email" <?php if($search_type == 'Email') : ?> selected <?php endif; ?>>Email</option>
	                                    </select>
	                                </div>
	                            </div>
	                        </div><!-- well -->
	                        <?php echo Form::open(array('url' => 'merchants/report/generate', 'style' => 'display:inline;', 'class' => 'form-horizontal form-bordered')); ?>

								<button class="btn btn-info"><i class="fa fa-file-excel-o"></i>&nbsp;Download List (.csv)</button>
							<?php echo Form::close(); ?>

							<a href="admin-merchant-details.html"><button class="btn btn-primary"><i class="fa fa-plus"></i> Add New Campaign</button></a>

	                        <hr />

	                        <div class="pull-right">

	                            <?php if($merchants->lastPage() > 1): ?>
								<ul class="pagination pagination-split pagination-sm pagination-contact">
								    <li class="<?php echo e(($merchants->currentPage() == 1) ? ' disabled' : ''); ?>">
								        <a href="<?php echo e($merchants->url(1)); ?>"><i class="fa fa-angle-left"></i></a>
								    </li>
								    <?php for($i = 1; $i <= $merchants->lastPage(); $i++): ?>
								        <li class="<?php echo e(($merchants->currentPage() == $i) ? ' active' : ''); ?>">
								            <a href="<?php echo e($merchants->url($i)); ?>"><?php echo e($i); ?></a>
								        </li>
								    <?php endfor; ?>
								    <li class="<?php echo e(($merchants->currentPage() == $merchants->lastPage()) ? ' disabled' : ''); ?>">
								        <a href="<?php echo e(($merchants->currentPage() == $merchants->lastPage()) ? '#' : $merchants->url($merchants->currentPage()+1)); ?>" ><i class="fa fa-angle-right"></i></a>
								    </li>
								</ul>
								<?php endif; ?>
	                        </div>
	                        <h3 class="xlg-title">All Merchants</h3>
	                       	<?php if(count($merchants) == 0): ?><br>
		                    <div class="alert alert-danger">
		                        <strong>No results found.</strong>
		                    </div>
		                    <?php endif; ?>
	                        <div class="list-group contact-group">
	                        	<?php foreach($merchants as $merchant): ?>
	                            <a href="<?php echo e(url('merchants/'.$merchant->mer_id.'/edit')); ?>" class="list-group-item">
	                                <div class="media">
	                                    <div class="pull-left">

	                                        <?php if(!is_null($merchant->res_logo)): ?>
	                                    	<img class="img-roundedcircle img-online" src="<?php echo e(env('MERCHANT_URL').'/'.$merchant->res_logo); ?>/profile_picture.jpg" alt="...">
	                                    	<?php else: ?>
	                                        <img class="img-roundedcircle img-online" src="<?php echo e(env('APP_URL')); ?>/images/photos/user1.png" alt="...">
	                                        <?php endif; ?>
	                                    </div>
	                                    <div class="media-body">
	                                        <h4 class="media-heading"><?php echo e($merchant->coy_name); ?></h4>
	                                        <div class="media-content">
	                                            <i class="fa fa-clock-o"></i> Last online at <?php echo e(date_format(date_create($merchant->last_online), 'd-M-Y H:i:s')); ?>

	                                            <ul class="list-unstyled">
													<li><i class="fa fa-briefcase"></i> <?php echo e($merchant->coy_name); ?></li>
													<li><i class="fa fa-toggle-on"></i>
													<?php if($merchant->status == 1): ?>
					                            	<span class="text-success"><strong>Approved</strong>
					                            	<?php elseif($merchant->status == 2): ?>
					                            	<span class="text-muted"><strong>Blocked</strong>
					                            	<?php elseif($merchant->status == 0): ?>
					                            	<span class="text-warning"><strong>Pending Admin Approval</strong>

					                            	<?php endif; ?>
													</span></small></li>

	                                            	<li><i class="fa fa-phone"></i> <?php echo e($merchant->coy_phone); ?></li>
													<li><i class="fa fa-envelope-o"></i> <?php echo e($merchant->coy_url); ?></li>
	                                            </ul>
	                                        </div>
	                                    </div>
	                                </div><!-- media -->
	                            </a><!-- list-group -->
	                            <?php endforeach; ?>
	                        </div><!-- list-group -->
	                    </div><!-- col-sm-9 -->
	                </div><!-- row -->
	            </div><!-- contentpanel -->
			</div><!-- mainpanel -->
	    </div><!-- mainwrapper -->
	</section>
	<input type="hidden" id="search_url" value="<?php echo e(url('')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-js'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
<script type="text/javascript" src="//cdn.datatables.net/plug-ins/725b2a2115b/integration/bootstrap/3/dataTables.bootstrap.js"></script>
<script type="text/javascript" src="//cdn.datatables.net/responsive/2.1.0/js/dataTables.responsive.min.js"></script>
<script>
	jQuery('#search-type').select2({
        minimumResultsForSearch: -1
    });
	$('#search-type').change(function(){
		/*$.ajax({
			url: '/merchants/search/'+ $('#input').val() + '/'+ $(this).val(),
			success:function(data){
				console.log(data);
			}
		});*/
		if($(this).val() != "" && $('#input').val() != "") {
			window.location.href = $('#search_url').val()+'/merchants/search/'+$('#input').val()+'/'+$(this).val();
		}


	})

    jQuery(document).ready(function(){

        jQuery('#live_merchants_table').DataTable({
            responsive: true,
            order: []
        });

        var shTable = jQuery('#shTable').DataTable({
            "fnDrawCallback": function(oSettings) {
                jQuery('#shTable_paginate ul').addClass('pagination-active-dark');
            },
            responsive: true
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>