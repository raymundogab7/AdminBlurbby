<div class="leftpanel">
    <div class="media profile-left">
        <a class="pull-left profile-thumb-rounded" href="admin-profile-admin.html">
            <img class="img-circle" src="<?php echo e(asset('images/photos/profile.png')); ?>" alt="">
        </a>
        <div class="media-body">
            <h4 class="media-heading"><?php echo e(Auth::user()->first_name); ?> <?php echo e(Auth::user()->last_name); ?></h4>
            <small class="text-muted">Super Admin</small>
        </div>
    </div><!-- media -->

    <h5 class="leftpanel-title">Navigation</h5>
    <ul class="nav nav-pills nav-stacked">
        <li class="<?php if(strpos(url()->current(), 'dashboard')): ?> active <?php endif; ?>"><a href="<?php echo e(url('dashboard')); ?>"><i class="fa fa-home"></i> <span>Dashboard</span></a></li>
        <li class="<?php if(strpos(url()->current(), 'featured-section')): ?> active <?php endif; ?>"><a href="<?php echo e(url('featured-section')); ?>"><i class="fa fa-star"></i> <span>Featured Section</span></a></li>
        <li class="<?php if(strpos(url()->current(), 'campaigns')): ?> active <?php endif; ?>"><a href="<?php echo e(url('campaigns')); ?>"><span class="pull-right badge">4</span><i class="fa fa-tags"></i> <span>Campaigns</span></a></li>
        <li class="<?php if(strpos(url()->current(), 'merchants')): ?> active <?php endif; ?>"><a href="<?php echo e(url('merchants')); ?>"><span class="pull-right badge">2</span><i class="fa fa-cutlery"></i> <span>Merchants</span></a></li>
        <li class="<?php if(strpos(url()->current(), 'administrators')): ?> active <?php endif; ?>"><a href="<?php echo e(url('administrators')); ?>"><i class="fa fa-user-secret"></i> <span>Administrators</span></a></li>
        <li class="<?php if(strpos(url()->current(), 'app-users')): ?> active <?php endif; ?>"><a href="<?php echo e(url('app-users')); ?>"><span class="pull-right badge">6</span><i class="fa fa-user"></i> <span>App Users</span></a></li>
        <li class="<?php if(strpos(url()->current(), 'blurb-reports')): ?> active <?php endif; ?>"><a href="<?php echo e(url('blurb-reports')); ?>"><span class="pull-right badge">1</span><i class="fa fa-exclamation-circle"></i> <span>Blurb Reports</span></a></li>
        <li class="<?php if(strpos(url()->current(), 'pages')): ?> active <?php endif; ?>"><a href="<?php echo e(url('pages')); ?>"><i class="fa fa-file-text"></i> <span>Pages</span></a></li>
        <li class="<?php if(strpos(url()->current(), 'settings')): ?> active <?php endif; ?>"><a href="<?php echo e(url('settings')); ?>"><i class="fa fa-gear"></i> <span>Settings</span></a></li> <!-- Add new cuisine and blurb category -->
        <li><a href="<?php echo e(url('logout')); ?>"><i class="fa fa-sign-out"></i> <span>Log Out</span></a></li>
    </ul>
</div><!-- leftpanel -->
