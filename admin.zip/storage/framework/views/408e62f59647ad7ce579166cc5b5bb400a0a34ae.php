
<script type="text/javascript" src="<?php echo e(asset('js/jquery-1.11.1.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/jquery-migrate-1.2.1.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/modernizr.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/pace.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/retina.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.cookies.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/select2.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/custom.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/merchant.js')); ?>"></script>
