<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
        <meta name="description" content="">
        <meta name="author" content="">

        <title><?php echo $__env->yieldContent('page-title'); ?> | Blurbes Dashboard</title>

        <?php echo $__env->make('layouts.blurbby-admin-css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </head>

    <body class="signin">

        <?php echo $__env->yieldContent('body-contents'); ?>

        <?php echo $__env->make('layouts.blurbby-admin-js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php echo $__env->yieldContent('custom-js'); ?>
    </body>
</html>
