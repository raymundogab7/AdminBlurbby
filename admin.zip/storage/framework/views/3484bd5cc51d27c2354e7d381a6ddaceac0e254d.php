<html>
	<table>


	 <tr>
    <?php foreach($report as $key => $r): ?>

    		<th align="center" ><?php echo e($key); ?></th>

    <?php endforeach; ?>
    </tr>
    <tr></tr>
    <?php $endLine = 1;?>
    <?php $count = count($report);?>
	    <?php foreach($testArray as $key => $r): ?>
	    	<?php if($endLine > $count): ?>
				<tr></tr>
				<?php $endLine = 1?>
	    	<?php endif; ?>
				<td align="left"><?php echo e($r); ?></td>

			<?php $endLine++?>
		<?php endforeach; ?>


	</table>
</html>