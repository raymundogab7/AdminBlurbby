<?php

namespace Admin\Http\Controllers;

use Illuminate\Http\Request;

use Admin\Http\Requests;

class HomeController extends Controller
{
    //
}
