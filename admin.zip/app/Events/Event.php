<?php

namespace Admin\Events;

abstract class Event
{
    //
}
